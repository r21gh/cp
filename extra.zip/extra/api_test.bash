#!/usr/bin/env bash
curl -i -X POST -F file=@test.png  http://127.0.0.1:5000/captcha
curl -i -H "Content-Type: application/json" -X POST -d '{"url":"https://r.divar.ir/guard/captcha_simple_image/"}' http://127.0.0.1:5000/captcha
curl 127.0.0.1:5000/health
