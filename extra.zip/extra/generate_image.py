from io import BytesIO
from captcha.image import ImageCaptcha
from random import randint

image = ImageCaptcha()

for i in xrange(0, 10000):
    value = str(randint(100, 999))  # randint is inclusive at both ends
    data = image.generate(value)
    image.write(value, './data/' + str(i) + '_' + value + '.png')
