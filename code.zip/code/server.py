from flask import Flask, abort, request, jsonify
from eval_test import CaptchaEval
import io, os
from PIL import Image
import json
import urllib
import logging
from threading import Thread
app = Flask(__name__)


captchaEval = CaptchaEval()
path = './trusted_data/'


def threaded_function(url, text):
    if not os.path.exists(path+text+".jpeg"):
        urllib.urlretrieve(url, path+text+".jpeg")
    else:
        for i in xrange(20):
            if not os.path.exists(path + str(i) + '_' + text + ".jpeg"):
                    urllib.urlretrieve(url, path + str(i) + '_' + text + ".jpeg")
                    break


@app.route('/data', methods=['POST'])
def data_grabber():
    url = request.json['url']
    text = request.json['text']

    if os.path.exists(path) == False:
        os.mkdir(path)
    thread = Thread(target=threaded_function, args=[url, text])
    thread.start()

    return jsonify(status_code='202', message='accepted')


@app.route('/captcha', methods=['POST'])
def index():
    try:
        fileContent = request.files['file']
        stream = io.BytesIO(fileContent.read())

        local_image = Image.open(fileContent)

        text = captchaEval.predict_from_img(local_image)

        return text
    except:

        image_url = request.json['url']
        urllib.urlretrieve(image_url, "filename.png")

        local_image = Image.open('filename.png')
        text = captchaEval.predict_from_img(local_image)

        return jsonify(text=text, status_code='200', message='success')


@app.route('/health', methods=['GET'])
def health():
    return request.data

if __name__ == '__main__':
    app.run(host='0.0.0.0', debug=False)
