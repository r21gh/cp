#
import os
for counter, file in enumerate(os.listdir('data')):
    print(file)
    os.rename('data/'+file, 'data/'+str(counter+813)+'_'+file)