# -*- coding: utf-8 -*-

from captcha.image import ImageCaptcha

# for python 2 uncomment these few lines
# import sys
#
# reload(sys)
# sys.setdefaultencoding('utf-8')

image = ImageCaptcha(width=103, height=23, fonts=['../fonts/Samim.ttf'], font_sizes=[20])
image.write('     ۱۲۳۴', 'out.png')
