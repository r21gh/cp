# -*- coding: utf-8 -*-

import urllib
import os


path = './data/'
if os.path.exists(path) == False:  # if the folder is not existed, create it
    os.mkdir(path)
# 10k train data
for counter, i in enumerate(xrange(1200,2678)):
    i = str(i)
    if len(i) ==1:
        i = '00' + str(i)
    if len(i) == 2:
        i = '0' + str(i)

    urllib.urlretrieve('http://94.232.172.172/Charter724/captcha_rezervation.aspx?id_request=4' + str(i), path+'{}.jpeg'.format(str(i)))
