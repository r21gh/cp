#!/usr/bin/env bash
curl -i -X POST -F file=@test.png  http://127.0.0.1:5000/captcha
curl -i -H "Content-Type: application/json" -X POST -d '{"url":"http://94.232.172.172/Charter724/captcha_rezervation.aspx?id_request=42592"}' http://127.0.0.1:5000/captcha
curl 127.0.0.1:5000/health
